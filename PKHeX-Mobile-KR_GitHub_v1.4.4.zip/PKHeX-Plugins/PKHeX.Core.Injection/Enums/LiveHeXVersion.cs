﻿namespace PKHeX.Core.Injection;

public enum LiveHeXVersion
{
    Unknown = -1,
    XY_v150 = 0,
    ORAS_v140 = 1,
    SM_v120 = 2,
    US_v120 = 3,
    UM_v120 = 4,

    SWSH_v111 = 5,
    SWSH_v121 = 6,
    SWSH_v132 = 7,

    LGPE_v102 = 8,

    SP_v100 = 9,
    SP_v110 = 10,
    SP_v111 = 11,
    SP_v130 = 12,

    BD_v100 = 13,
    BD_v110 = 14,
    BD_v111 = 15,
    BD_v130 = 16,

    BDSP_v112 = 17,
    BDSP_v113 = 18,
    BDSP_v120 = 19,

    LA_v100 = 20,
    LA_v101 = 21,
    LA_v102 = 22,
    LA_v111 = 23,

    SV_v101 = 24,
    SV_v110 = 25,
    SV_v120 = 26,
    SV_v130 = 27,
    SV_v131 = 28,
    SV_v132 = 29,
    SV_v201 = 30,
    SV_v202 = 31,
    SV_v300 = 32,
    SV_v301 = 33,
    SV_v400 = 34,

    ZA_v101 = 35,
    ZA_v102 = 36,
    ZA_v103 = 37,
    ZA_v200 = 38,
    ZA_v201 = 39,
    ZA_v202 = 40,

    FRLG_E_v100 = 41,
    FRLG_S_v100 = 42,
    FRLG_F_v100 = 43,
    FRLG_D_v100 = 44,
    FRLG_I_v100 = 45,
    FRLG_J_v100 = 46,
}
