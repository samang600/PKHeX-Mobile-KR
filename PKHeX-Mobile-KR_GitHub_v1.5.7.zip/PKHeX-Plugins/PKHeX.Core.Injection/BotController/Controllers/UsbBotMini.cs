﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using LibUsbDotNet;
using LibUsbDotNet.Main;
using static System.Buffers.Binary.BinaryPrimitives;

namespace PKHeX.Core.Injection;

public sealed class UsbBotMini : ICommunicatorNX, IPokeBlocks
{
    private const int MaximumTransferSize = 468; // byte limitation of USB-Botbase over Android for ACNHMS, assumed same here.

    public string IP = string.Empty;
    public int Port;
    public InjectorCommunicationType Protocol = InjectorCommunicationType.USB;

    private UsbDevice? SwDevice;
    private UsbEndpointReader? reader;
    private UsbEndpointWriter? writer;

    public bool Connected;

    private readonly Lock _sync = new();

    InjectorCommunicationType ICommunicatorNX.Protocol
    {
        get => Protocol;
        set => Protocol = value;
    }
    bool ICommunicator.Connected
    {
        get => Connected;
        set => Connected = SwDevice is not null;
    }
    int ICommunicator.Port
    {
        get => Port;
        set => Port = value;
    }
    string ICommunicator.IP
    {
        get => IP;
        set => IP = value;
    }

    /// <summary>
    /// Soft connect USB reader and writer, no persistent connection will be active due to limitations of USB-Botbase.
    /// </summary>
    public void Connect()
    {
        lock (_sync)
        {
            // Find and open the usb device.
            foreach (UsbRegistry ur in UsbDevice.AllDevices.Cast<UsbRegistry>())
            {
                if (ur.Vid != 0x057E)
                    continue;

                if (ur.Pid != 0x3000)
                    continue;

                ur.DeviceProperties.TryGetValue("Address", out object? addr);
                if (Port.ToString() != addr?.ToString())
                    continue;

                SwDevice = ur.Device;
            }

            // If the device is open and ready
            if (SwDevice == null)
                throw new Exception("USB device not found.");

            if (SwDevice is not IUsbDevice usb)
                throw new Exception("Device is using a WinUSB driver. Use libusbK and create a filter.");

            if (!usb.UsbRegistryInfo.IsAlive)
                usb.ResetDevice();

            if (SwDevice.IsOpen)
                SwDevice.Close();

            SwDevice.Open();

            if (SwDevice is IUsbDevice wholeUsbDevice)
            {
                // This is a "whole" USB device. Before it can be used,
                // the desired configuration and interface must be selected.

                // Select config #1
                wholeUsbDevice.SetConfiguration(1);

                // Claim interface #0.
                bool resagain = wholeUsbDevice.ClaimInterface(0);
                if (!resagain)
                {
                    wholeUsbDevice.ReleaseInterface(0);
                    wholeUsbDevice.ClaimInterface(0);
                }
            }
            else
            {
                Disconnect();
                throw new Exception("Device is using WinUSB driver. Use libusbK and create a filter");
            }

            // open read write endpoints 1.
            reader = SwDevice.OpenEndpointReader(ReadEndpointID.Ep01);
            writer = SwDevice.OpenEndpointWriter(WriteEndpointID.Ep01);

            Connected = true;
        }
    }

    public void Disconnect()
    {
        lock (_sync)
        {
            if (SwDevice is { IsOpen: true })
            {
                if (SwDevice is IUsbDevice wholeUsbDevice)
                    wholeUsbDevice.ReleaseInterface(0);

                SwDevice.Close();
            }

            reader?.Dispose();
            writer?.Dispose();
            SwDevice = null;
            Connected = false;
        }
    }

    public Span<byte> ReadBytes(ulong offset, int length) => ReadBytesUSB(offset, length, RWMethod.Heap);

    public void WriteBytes(ReadOnlySpan<byte> data, ulong offset) => WriteBytesUSB(data, offset, RWMethod.Heap);

    public byte[] ReadBytesMain(ulong offset, int length) => ReadBytesUSB(offset, length, RWMethod.Main);

    public void WriteBytesMain(ReadOnlySpan<byte> data, ulong offset) => WriteBytesUSB(data, offset, RWMethod.Main);

    public byte[] ReadBytesAbsolute(ulong offset, int length) => ReadBytesUSB(offset, length, RWMethod.Absolute);

    public void WriteBytesAbsolute(ReadOnlySpan<byte> data, ulong offset) => WriteBytesUSB(data, offset, RWMethod.Absolute);

    public byte[] ReadBytesAbsoluteMulti(Dictionary<ulong, int> offsets) => ReadAbsoluteMultiUSB(offsets);

    public ulong GetHeapBase()
    {
        var cmd = SwitchCommand.GetHeapBase();
        SendInternal(cmd);
        var buffer = new byte[(8 * 2) + 1];
        _ = ReadInternal(buffer);
        if (buffer.Length < sizeof(ulong))
        {
            Debug.WriteLine($"{nameof(GetHeapBase)}: Invalid response length");
            return 0;
        }
        return ReadUInt64LittleEndian(buffer);
    }

    public string GetTitleID()
    {
        SendInternal(SwitchCommand.GetTitleID(false));
        byte[] baseBytes = ReadBulkUSB();
        if (baseBytes.Length == 0)
        {
            Debug.WriteLine($"{nameof(GetTitleID)}: Invalid response");
            return string.Empty;
        }
        return ReadUInt64LittleEndian(baseBytes).ToString("X16").Trim();
    }

    public string GetBotbaseVersion()
    {
        SendInternal(SwitchCommand.GetBotbaseVersion(false));
        byte[] baseBytes = ReadBulkUSB();
        if (baseBytes.Length == 0)
        {
            Debug.WriteLine($"{nameof(GetBotbaseVersion)}: Invalid response");
            return string.Empty;
        }
        return Encoding.UTF8.GetString(baseBytes).Trim('\0');
    }

    public string GetGameInfo(string info)
    {
        SendInternal(SwitchCommand.GetGameInfo(info, false));
        byte[] baseBytes = ReadBulkUSB();
        if (baseBytes.Length == 0)
        {
            Debug.WriteLine($"{nameof(GetGameInfo)}: Invalid response");
            return string.Empty;
        }
        return Encoding.UTF8.GetString(baseBytes).Trim('\0');
    }

    public bool IsProgramRunning(ulong pid)
    {
        SendInternal(SwitchCommand.IsProgramRunning(pid, false));
        byte[] baseBytes = ReadBulkUSB();
        if (baseBytes.Length == 0)
        {
            Debug.WriteLine($"{nameof(IsProgramRunning)}: Invalid response");
            return false;
        }
        return baseBytes.Length == 1 && BitConverter.ToBoolean(baseBytes, 0);
    }

    private int ReadInternal(byte[] buffer)
    {
        try
        {
            byte[] sizeOfReturn = new byte[4];
            if (reader == null)
                throw new Exception("USB device not found or not connected.");

            var ec = reader.Read(sizeOfReturn, 5000, out int ret);
            if (ec != ErrorCode.None && ret == 0)
                throw new Exception(UsbDevice.LastErrorString);

            ec = reader.Read(buffer, 5000, out var lenVal);
            if (ec != ErrorCode.None)
                throw new Exception(UsbDevice.LastErrorString);

            return lenVal;
        }
        catch (Exception ex)
        {
            // Win32Error is returned when the device aborts a transfer, which happens when, for example, readMem() is called with an invalid address.
            // As such, we ignore it to avoid log spam, log other exceptions, and return 0 to maintain connection.
            var lastError = UsbDevice.LastErrorNumber;
            if (lastError is not (int)ErrorCode.Win32Error)
                Debug.WriteLine($"{nameof(ReadInternal)} failed: {ex.Message}");
            return 0;
        }
    }


    private int SendInternal(byte[] buffer)
    {
        try
        {
            if (writer == null)
                throw new Exception("USB device not found or not connected.");

            uint pack = (uint)buffer.Length + 2;
            var ec = writer.Write(BitConverter.GetBytes(pack), 2000, out int ret);
            if (ec != ErrorCode.None && ret == 0)
                throw new Exception(UsbDevice.LastErrorString);

            ec = writer.Write(buffer, 2000, out var l);
            if (ec != ErrorCode.None)
                throw new Exception(UsbDevice.LastErrorString);

            return l;
        }
        catch (Exception ex)
        {
            // Win32Error is returned when the device aborts a transfer, which happens when, for example, readMem() is called with an invalid address.
            // As such, we ignore it to avoid log spam, log other exceptions, and return 0 to maintain connection.
            var lastError = UsbDevice.LastErrorNumber;
            if (lastError is not (int)ErrorCode.Win32Error)
                Debug.WriteLine($"{nameof(SendInternal)} failed: {ex.Message}");
            return 0;
        }
    }

    public int Read(byte[] buffer)
    {
        lock (_sync)
        {
            return ReadInternal(buffer);
        }
    }

    public byte[] ReadBytesUSB(ulong offset, int length, RWMethod method)
    {
        lock (_sync)
        {
            var cmd = method switch
            {
                RWMethod.Heap => SwitchCommand.Peek(offset, length, false),
                RWMethod.Main => SwitchCommand.PeekMain(offset, length, false),
                RWMethod.Absolute => SwitchCommand.PeekAbsolute(offset, length, false),
                _ => SwitchCommand.Peek(offset, length, false),
            };

            SendInternal(cmd);
            return ReadBulkUSB();
        }
    }

    public byte[] ReadAbsoluteMultiUSB(Dictionary<ulong, int> offsets)
    {
        lock (_sync)
        {
            var cmd = SwitchCommand.PeekAbsoluteMulti(offsets, false);
            SendInternal(cmd);
            return ReadBulkUSB();
        }
    }

    private byte[] ReadBulkUSB()
    {
        // Give it time to push back.
        Thread.Sleep(1);

        lock (_sync)
        {
            try
            {
                if (reader == null)
                    throw new Exception("USB device not found or not connected.");

                // Let usb-botbase tell us the response size.
                byte[] sizeOfReturn = new byte[4];
                var ec = reader.Read(sizeOfReturn, 5000, out int ret);
                if (ec != ErrorCode.None && ret == 0)
                    throw new Exception(UsbDevice.LastErrorString);

                int size = BitConverter.ToInt32(sizeOfReturn, 0);
                byte[] buffer = new byte[size];

                // Loop until we have read everything.
                int transfSize = 0;
                while (transfSize < size)
                {
                    Thread.Sleep(1);
                    ec = reader.Read(buffer, transfSize, Math.Min(reader.ReadBufferSize, size - transfSize), 5000, out int lenVal);
                    if (ec != ErrorCode.None)
                        throw new Exception(UsbDevice.LastErrorString);

                    transfSize += lenVal;
                }
                return buffer;
            }
            catch (Exception ex)
            {
                // Win32Error is returned when the device aborts a transfer, which happens when, for example, readMem() is called with an invalid address.
                // As such, we ignore it to avoid log spam but still return a zero-buffer to avoid crashing the caller, and to maintain connection.
                var lastError = UsbDevice.LastErrorNumber;
                if (lastError is not (int)ErrorCode.Win32Error)
                    Debug.WriteLine($"{nameof(ReadBulkUSB)} failed: {ex.Message}");
                return [0];
            }
        }
    }

    public void WriteBytesUSB(ReadOnlySpan<byte> data, ulong offset, RWMethod method)
    {
        if (data.Length > MaximumTransferSize)
        {
            WriteBytesLarge(data, offset, method);
        }
        else
        {
            WriteSmall(data, offset, method);
        }
    }

    public void WriteSmall(ReadOnlySpan<byte> data, ulong offset, RWMethod method)
    {
        lock (_sync)
        {
            var cmd = method switch
            {
                RWMethod.Heap => SwitchCommand.Poke(offset, data, false),
                RWMethod.Main => SwitchCommand.PokeMain(offset, data, false),
                RWMethod.Absolute => SwitchCommand.PokeAbsolute(offset, data, false),
                _ => SwitchCommand.Poke(offset, data, false),
            };

            SendInternal(cmd);
            Thread.Sleep(1);
        }
    }

    private void WriteBytesLarge(ReadOnlySpan<byte> data, ulong offset, RWMethod method)
    {
        int byteCount = data.Length;
        for (int i = 0; i < byteCount; i += MaximumTransferSize)
        {
            var slice = SliceSafe(data, i, MaximumTransferSize);
            WriteBytesUSB(slice, offset + (ulong)i, method);
        }
    }

    // Taken from SysBot.
    private static ReadOnlySpan<byte> SliceSafe(ReadOnlySpan<byte> src, int offset, int length)
    {
        var delta = src.Length - offset;
        if (delta < length)
        {
            length = delta;
        }

        return src.Slice(offset, length);
    }
}
